
package miniplayertest;

/**
 *
 * @author Dr. Hoffman
 */
public class MiniPlayerTest {

    /**
     * @param args the command line arguments
     */
        
    public static void main(String[] args) {
        MiniPlayerGUI   gui = new MiniPlayerGUI();
        
        gui.go();

    }
    
}
